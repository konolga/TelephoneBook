import { Component } from '@angular/core';

@Component({
  selector: 'app-sever',
  templateUrl: 'server.component.html'
})

export class ServerComponent {

}
