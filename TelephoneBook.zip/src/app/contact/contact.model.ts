export class Contact {
  public id: string;
  public name: string;
  public telephone: string;

  constructor(id: string, name: string, telephone: string) {
    this.id = id;
    this.name = name;
    this.telephone = telephone;
    }
}

