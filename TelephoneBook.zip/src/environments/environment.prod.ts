export const environment = {
  production: true,
  apiUrl: "https://konolga.github.io/TelephoneBook/"
};
